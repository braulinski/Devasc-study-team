import tkinter as tk
from models.categoria import CategoriaWindow
from models.articulo import ArticuloWindow
from models.cliente import ClienteWindow
from models.empleado import EmpleadoWindow
from database import init_db

class MainWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("CRUD de Catálogos")
        self.root.geometry("300x200")

        # Botones de navegación
        btn_categoria = tk.Button(root, text="Categorías", command=self.open_categoria)
        btn_categoria.pack(pady=5)

        btn_articulo = tk.Button(root, text="Artículos", command=self.open_articulo)
        btn_articulo.pack(pady=5)

        btn_cliente = tk.Button(root, text="Clientes", command=self.open_cliente)
        btn_cliente.pack(pady=5)

        btn_empleado = tk.Button(root, text="Empleados", command=self.open_empleado)
        btn_empleado.pack(pady=5)

    def open_categoria(self):
        categoria_win = tk.Toplevel(self.root)
        CategoriaWindow(categoria_win)

    def open_articulo(self):
        articulo_win = tk.Toplevel(self.root)
        ArticuloWindow(articulo_win)

    def open_cliente(self):
        cliente_win = tk.Toplevel(self.root)
        ClienteWindow(cliente_win)

    def open_empleado(self):
        empleado_win = tk.Toplevel(self.root)
        EmpleadoWindow(empleado_win)

if __name__ == "__main__":
    init_db()  # Inicializa la base de datos si es necesario
    root = tk.Tk()
    app = MainWindow(root)
    root.mainloop()
