import sqlite3

DB_NAME = "catalogos.db"

def get_connection():
    return sqlite3.connect(DB_NAME)

def init_db():
    schema = {
        "categorias": """
            CREATE TABLE IF NOT EXISTS categorias (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL
            )
        """,
        "articulos": """
            CREATE TABLE IF NOT EXISTS articulos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                descripcion TEXT,
                precio REAL,
                categoria_id INTEGER,
                FOREIGN KEY(categoria_id) REFERENCES categorias(id)
            )
        """,
        "clientes": """
            CREATE TABLE IF NOT EXISTS clientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                correo TEXT,
                telefono TEXT
            )
        """,
        "empleados": """
            CREATE TABLE IF NOT EXISTS empleados (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                puesto TEXT,
                correo TEXT
            )
        """
    }

    with get_connection() as conn:
        cursor = conn.cursor()
        for table_sql in schema.values():
            cursor.execute(table_sql)
        conn.commit()
