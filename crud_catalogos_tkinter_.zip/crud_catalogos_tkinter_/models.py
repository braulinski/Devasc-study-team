import tkinter as tk
from tkinter import ttk, messagebox
from database import get_connection

class CategoriaWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("Categorías")
        self.root.geometry("400x300")

        # Entrada de texto para nombre
        self.input_nombre = tk.Entry(root)
        self.input_nombre.pack(pady=5)
        self.input_nombre.insert(0, "Nombre de la categoría")

        # Botón para agregar
        self.btn_agregar = tk.Button(root, text="Agregar", command=self.agregar_categoria)
        self.btn_agregar.pack(pady=5)

        # Tabla
        self.tabla = ttk.Treeview(root, columns=("ID", "Nombre"), show="headings")
        self.tabla.heading("ID", text="ID")
        self.tabla.heading("Nombre", text="Nombre")
        self.tabla.pack(expand=True, fill="both")

        self.cargar_datos()

    def agregar_categoria(self):
        nombre = self.input_nombre.get().strip()
        if nombre and nombre != "Nombre de la categoría":
            try:
                with get_connection() as conn:
                    cursor = conn.cursor()
                    cursor.execute("INSERT INTO categorias (nombre) VALUES (?)", (nombre,))
                    conn.commit()
                self.input_nombre.delete(0, tk.END)
                self.cargar_datos()
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo agregar la categoría:\n{e}")
        else:
            messagebox.showwarning("Advertencia", "El nombre no puede estar vacío.")

    def cargar_datos(self):
        for row in self.tabla.get_children():
            self.tabla.delete(row)
        try:
            with get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM categorias")
                for row in cursor.fetchall():
                    self.tabla.insert("", "end", values=row)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos:\n{e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = CategoriaWindow(root)
    root.mainloop()
