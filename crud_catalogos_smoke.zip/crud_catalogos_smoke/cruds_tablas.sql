-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS smoke_base_de_datos;
USE smoke_base_de_datos;

-- Tabla de productos
CREATE TABLE productos (
    idprod INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL
);

-- Tabla de empleados
CREATE TABLE empleados (
    idemp INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    puesto VARCHAR(100),
    sexo CHAR(1),
    telefono VARCHAR(15),
    CHECK (sexo IN ('M', 'F', 'O'))  -- Validación opcional
);

-- Tabla de clientes
CREATE TABLE clientes (
    idcliente INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(100) NOT NULL,
    correo VARCHAR(100),
    telefono VARCHAR(15)
);

-- Tabla de pedidos
CREATE TABLE pedidos (
    idpedido INT AUTO_INCREMENT PRIMARY KEY,
    idcliente INT NOT NULL,
    idemp INT NOT NULL,
    fecha DATE NOT NULL,
    total DECIMAL(10,2),
    estpedido VARCHAR(50),
    FOREIGN KEY (idcliente) REFERENCES clientes(idcliente),
    FOREIGN KEY (idemp) REFERENCES empleados(idemp)
);

