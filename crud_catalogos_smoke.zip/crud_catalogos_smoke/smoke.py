
import ttkbootstrap as tb # type: ignore
from ttkbootstrap.constants import * # type: ignore
from tkinter import messagebox
from crud_productos import abrir_crud_productos 
from crud_categoria import abrir_crud_categoria
from crud_empleados import abrir_crud_empleados
from crud_clientes import abrir_crud_clientes
from crud_pedidos import abrir_crud_pedidos
from conexion import conectar

# Crear ventana principal con tema profesional
app = tb.Window(themename="flatly")  # Puedes cambiar "flatly" por "darkly", "morph", etc.
app.title("Smoke Shop - Menú Principal")
app.geometry("900x600")
app.resizable(False, False)

# Estilos y fuentes
FUENTE_TITULO = ("Segoe UI", 34, "bold")
FUENTE_SUBTITULO = ("Segoe UI", 18)
FUENTE_BOTON = ("Segoe UI", 13, "bold")
COLOR_TEXTO = "#222222"
PADDING_X = 30

# Header
header_frame = tb.Frame(app, padding=20)
header_frame.pack(fill=X)

titulo = tb.Label(
    header_frame,
    text="Smoke Shop",
    font=FUENTE_TITULO,
    foreground=COLOR_TEXTO
)
titulo.pack()

subtitulo = tb.Label(
    header_frame,
    text="Bienvenido",
    font=FUENTE_SUBTITULO,
    foreground="#555"
)
subtitulo.pack()

# Separador visual
tb.Separator(app, bootstyle="secondary").pack(fill=X, padx=40, pady=10)

# Contenedor de botones
contenido_frame = tb.Frame(app, padding=(PADDING_X, 10))
contenido_frame.pack()

# Opciones del menú

opciones = [
    ("🛒  Productos", abrir_crud_productos),
    ("👥  Empleados", abrir_crud_empleados),
    ("👤  Clientes", abrir_crud_clientes),
    ("📦  Pedidos", abrir_crud_pedidos),
]

for i, (texto, comando) in enumerate(opciones):
    boton = tb.Button(
        contenido_frame,
        text=texto,
        command=comando,
        bootstyle="primary outline",  # Estilo profesional
        width=30,
        padding=10
    )
    boton.pack(pady=8)

# Emoji decorativo grande
emoji = tb.Label(
    app,
    text="",
    font=("Segoe UI Emoji", 60),
    anchor="center"
)
emoji.place(relx=0.92, rely=0.85, anchor="center")

# Footer
footer = tb.Label(
    app,
    text="",
    font=("Segoe UI", 10),
    foreground="#888"
)
footer.pack(side="bottom", pady=10)

# Ejecutar app
app.mainloop()
