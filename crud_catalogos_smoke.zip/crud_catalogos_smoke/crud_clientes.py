import ttkbootstrap as tb  # type: ignore
from ttkbootstrap.constants import *  # type: ignore
from tkinter import messagebox, simpledialog
from conexion import conectar

def agregar_cliente():
    conexion = conectar()
    if conexion:
        try:
            cursor = conexion.cursor()
            # Solicitar datos dinámicos al usuario
            nombre = simpledialog.askstring("Agregar Cliente", "Nombre del cliente:")
            telefono = simpledialog.askstring("Agregar Cliente", "Teléfono del cliente:")
            email = simpledialog.askstring("Agregar Cliente", "Email del cliente:")

            if not nombre or not telefono or not email:
                messagebox.showwarning("Advertencia", "Todos los campos son obligatorios.")
                return

            consulta = "INSERT INTO clientes (nombre, telefono, email) VALUES (%s, %s, %s)"
            cursor.execute(consulta, (nombre, telefono, email))
            conexion.commit()
            messagebox.showinfo("Éxito", "Cliente agregado correctamente")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo agregar el cliente: {e}")
        finally:
            conexion.close()

def ver_clientes():
    conexion = conectar()
    if conexion:
        try:
            cursor = conexion.cursor()
            cursor.execute("SELECT * FROM clientes")
            clientes = cursor.fetchall()
            # Mostrar los clientes en un mensaje
            if clientes:
                mensaje = "\n".join([f"ID: {c[0]}, Nombre: {c[1]}, Teléfono: {c[2]}, Email: {c[3]}" for c in clientes])
                messagebox.showinfo("Clientes", mensaje)
            else:
                messagebox.showinfo("Clientes", "No hay clientes registrados.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo obtener la lista de clientes: {e}")
        finally:
            conexion.close()

def abrir_crud_clientes():
    # Crear ventana para CRUD de clientes
    app = tb.Window(themename="flatly")
    app.title("Smoke Shop - Gestión de Clientes")
    app.geometry("900x600")
    app.resizable(False, False)

    # Estilos y fuentes
    FUENTE_TITULO = ("Segoe UI", 34, "bold")
    FUENTE_SUBTITULO = ("Segoe UI", 18)
    FUENTE_BOTON = ("Segoe UI", 13, "bold")
    COLOR_TEXTO = "#222222"
    PADDING_X = 30

    # Header
    header_frame = tb.Frame(app, padding=20)
    header_frame.pack(fill=X)

    titulo = tb.Label(
        header_frame,
        text="Gestión de Clientes",
        font=FUENTE_TITULO,
        foreground=COLOR_TEXTO
    )
    titulo.pack()

    subtitulo = tb.Label(
        header_frame,
        text="Administra los datos de tus clientes",
        font=FUENTE_SUBTITULO,
        foreground="#555"
    )
    subtitulo.pack()

    # Separador visual
    tb.Separator(app, bootstyle="secondary").pack(fill=X, padx=40, pady=10)

    # Contenedor de botones
    contenido_frame = tb.Frame(app, padding=(PADDING_X, 10))
    contenido_frame.pack()

    # Opciones del CRUD
    opciones = [
        ("➕  Agregar Cliente", agregar_cliente),
        ("📋  Ver Clientes", ver_clientes),
    ]

    for i, (texto, comando) in enumerate(opciones):
        boton = tb.Button(
            contenido_frame,
            text=texto,
            command=comando,
            bootstyle="primary outline",
            width=30,
            padding=10
        )
        boton.pack(pady=8)

    # Footer
    footer = tb.Label(
        app,
        text="Gestión de Clientes - Smoke Shop",
        font=("Segoe UI", 10),
        foreground="#888"
    )
    footer.pack(side="bottom", pady=10)

    # Ejecutar ventana
    app.mainloop()