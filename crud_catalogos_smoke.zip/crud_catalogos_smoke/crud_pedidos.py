import ttkbootstrap as tb  # type: ignore
from ttkbootstrap.constants import *  # type: ignore
from tkinter import messagebox, simpledialog
from datetime import date
from conexion import conectar  # Importa la función de conexión

def abrir_crud_pedidos():
    # Crear ventana para CRUD de pedidos
    app = tb.Window(themename="flatly")
    app.title("Smoke Shop - Gestión de Pedidos")
    app.geometry("900x600")
    app.resizable(False, False)

    # Estilos y fuentes
    FUENTE_TITULO = ("Segoe UI", 34, "bold")
    FUENTE_SUBTITULO = ("Segoe UI", 18)
    FUENTE_BOTON = ("Segoe UI", 13, "bold")
    COLOR_TEXTO = "#222222"
    PADDING_X = 30

    # Header
    header_frame = tb.Frame(app, padding=20) 
    header_frame.pack(fill=X)

    titulo = tb.Label(
        header_frame,
        text="Gestión de Pedidos",
        font=FUENTE_TITULO,
        foreground=COLOR_TEXTO
    )
    titulo.pack()

    subtitulo = tb.Label(
        header_frame,
        text="Administra los datos de tus pedidos",
        font=FUENTE_SUBTITULO,
        foreground="#555"
    )
    subtitulo.pack()

    # Separador visual
    tb.Separator(app, bootstyle="secondary").pack(fill=X, padx=40, pady=10)

    # Contenedor de botones
    contenido_frame = tb.Frame(app, padding=(PADDING_X, 10))
    contenido_frame.pack()

    # Funciones CRUD
    def obtener_clientes():
        try:
            conexion = conectar()
            if not conexion:
                raise Exception("No se pudo establecer la conexión con la base de datos.")
            cursor = conexion.cursor()
            cursor.execute("SELECT idcliente, usuario FROM clientes")
            datos = cursor.fetchall()
            conexion.close()
            return datos
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron obtener los clientes.\n{e}")
            return []

    def obtener_empleados():
        try:
            conexion = conectar()
            if not conexion:
                raise Exception("No se pudo establecer la conexión con la base de datos.")
            cursor = conexion.cursor()
            cursor.execute("SELECT idemp, nombre FROM empleados")
            datos = cursor.fetchall()
            conexion.close()
            return datos
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron obtener los empleados.\n{e}")
            return []

    def crear_pedido():
        clientes = obtener_clientes()
        empleados = obtener_empleados()

        if not clientes or not empleados:
            return

        dic_cli = {f"{c[1]} (ID: {c[0]})": c[0] for c in clientes}
        dic_emp = {f"{e[1]} (ID: {e[0]})": e[0] for e in empleados}

        seleccion_cli = simpledialog.askstring("Crear Pedido", "Selecciona cliente:\n" + "\n".join(dic_cli.keys()))
        seleccion_emp = simpledialog.askstring("Crear Pedido", "Selecciona empleado:\n" + "\n".join(dic_emp.keys()))
        total = simpledialog.askfloat("Crear Pedido", "Total del pedido:")
        estpedido = simpledialog.askstring("Crear Pedido", "Estado (Ej: Pendiente, Enviado, Entregado):")

        idcli = dic_cli.get(seleccion_cli)
        idemp = dic_emp.get(seleccion_emp)

        if idcli and idemp and total is not None and estpedido:
            try:
                conexion = conectar()
                if not conexion:
                    raise Exception("No se pudo establecer la conexión con la base de datos.")
                cursor = conexion.cursor()
                cursor.execute(
                    "INSERT INTO pedidos (idcliente, idemp, fecha, total, estpedido) VALUES (%s, %s, %s, %s, %s)",
                    (idcli, idemp, date.today(), total, estpedido)
                )
                conexion.commit()
                conexion.close()
                messagebox.showinfo("Éxito", "Pedido creado correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo crear el pedido.\n{e}")

    def leer_pedidos():
        try:
            conexion = conectar()
            if not conexion:
                raise Exception("No se pudo establecer la conexión con la base de datos.")
            cursor = conexion.cursor()
            cursor.execute("""
                SELECT p.idpedido, c.usuario, e.nombre, p.fecha, p.total, p.estpedido
                FROM pedidos p
                JOIN clientes c ON p.idcliente = c.idcliente
                JOIN empleados e ON p.idemp = e.idemp
            """)
            pedidos = cursor.fetchall()
            conexion.close()

            texto = "\n".join([
                f"ID: {p[0]} | Cliente: {p[1]} | Empleado: {p[2]} | Fecha: {p[3]} | Total: ${p[4]} | Estado: {p[5]}"
                for p in pedidos
            ])
            messagebox.showinfo("Pedidos Registrados", texto if texto else "No hay pedidos registrados.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo leer la tabla pedidos.\n{e}")

    def actualizar_pedido():
        idpedido = simpledialog.askinteger("Actualizar Pedido", "ID del pedido a modificar:")

        clientes = obtener_clientes()
        empleados = obtener_empleados()
        if not clientes or not empleados:
            return

        dic_cli = {f"{c[1]} (ID: {c[0]})": c[0] for c in clientes}
        dic_emp = {f"{e[1]} (ID: {e[0]})": e[0] for e in empleados}

        seleccion_cli = simpledialog.askstring("Actualizar Pedido", "Nuevo cliente:\n" + "\n".join(dic_cli.keys()))
        seleccion_emp = simpledialog.askstring("Actualizar Pedido", "Nuevo empleado:\n" + "\n".join(dic_emp.keys()))
        fecha_str = simpledialog.askstring("Actualizar Pedido", "Nueva fecha (AAAA-MM-DD):")
        total = simpledialog.askfloat("Actualizar Pedido", "Nuevo total:")
        estpedido = simpledialog.askstring("Actualizar Pedido", "Nuevo estado:")

        idcli = dic_cli.get(seleccion_cli)
        idemp = dic_emp.get(seleccion_emp)

        if idpedido and idcli and idemp and fecha_str and total is not None and estpedido:
            try:
                conexion = conectar()
                if not conexion:
                    raise Exception("No se pudo establecer la conexión con la base de datos.")
                cursor = conexion.cursor()
                cursor.execute(
                    "UPDATE pedidos SET idcliente=%s, idemp=%s, fecha=%s, total=%s, estpedido=%s WHERE idpedido=%s",
                    (idcli, idemp, fecha_str, total, estpedido, idpedido)
                )
                conexion.commit()
                conexion.close()
                messagebox.showinfo("Éxito", "Pedido actualizado correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo actualizar el pedido.\n{e}")

    def eliminar_pedido():
        idpedido = simpledialog.askinteger("Eliminar Pedido", "ID del pedido a eliminar:")
        if idpedido:
            try:
                conexion = conectar()
                if not conexion:
                    raise Exception("No se pudo establecer la conexión con la base de datos.")
                cursor = conexion.cursor()
                cursor.execute("DELETE FROM pedidos WHERE idpedido=%s", (idpedido,))
                conexion.commit()
                conexion.close()
                messagebox.showinfo("Éxito", "Pedido eliminado correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo eliminar el pedido.\n{e}")

    # Botones CRUD
    opciones = [
        ("➕  Crear Pedido", crear_pedido),
        ("📋  Leer Pedidos", leer_pedidos),
        ("✏️  Actualizar Pedido", actualizar_pedido),
        ("🗑️  Eliminar Pedido", eliminar_pedido),
    ]

    for texto, comando in opciones:
        boton = tb.Button(
            contenido_frame,
            text=texto,
            command=comando,
            bootstyle="primary outline",
            width=30,
            padding=10
        )
        boton.pack(pady=8)

    # Footer
    footer = tb.Label(
        app,
        text="Gestión de Pedidos - Smoke Shop",
        font=("Segoe UI", 10),
        foreground="#888"
    )
    footer.pack(side="bottom", pady=10)

    # Ejecutar ventana
    try:
        app.mainloop()
    except Exception as e:
        messagebox.showerror("Error crítico", f"Se produjo un error inesperado: {e}")