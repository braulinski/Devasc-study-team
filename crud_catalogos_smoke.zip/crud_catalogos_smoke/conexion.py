import mysql.connector
from mysql.connector import Error

def conectar():
    try:
        conexion = mysql.connector.connect(
            host="localhost",
            port="3306",
            user="root",
            password="",
            database="smoke_shop"
        )
        if conexion.is_connected():
            print("✅ Conexión exitosa a la base de datos 'smoke_shop'")
            return conexion
    except Error as e:
        print(f"❌ Error al conectar a la base de datos: {e}")
    return None  # Asegura que siempre retorne algo