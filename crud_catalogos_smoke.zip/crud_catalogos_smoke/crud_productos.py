import ttkbootstrap as tb  # type: ignore
from ttkbootstrap.constants import *  # type: ignore
from tkinter import messagebox, simpledialog
from conexion import conectar

def abrir_crud_productos():
    # Crear ventana para CRUD de productos
    app = tb.Window(themename="flatly")
    app.title("Smoke Shop - Gestión de Productos")
    app.geometry("900x600")
    app.resizable(False, False)

    # Estilos y fuentes
    FUENTE_TITULO = ("Segoe UI", 34, "bold")
    FUENTE_SUBTITULO = ("Segoe UI", 18)
    FUENTE_BOTON = ("Segoe UI", 13, "bold")
    COLOR_TEXTO = "#222222"
    PADDING_X = 30

    # Header
    header_frame = tb.Frame(app, padding=20)
    header_frame.pack(fill=X)

    titulo = tb.Label(
        header_frame,
        text="Gestión de Productos",
        font=FUENTE_TITULO,
        foreground=COLOR_TEXTO
    )
    titulo.pack()

    subtitulo = tb.Label(
        header_frame,
        text="Administra los datos de tus productos",
        font=FUENTE_SUBTITULO,
        foreground="#555"
    )
    subtitulo.pack()

    # Separador visual
    tb.Separator(app, bootstyle="secondary").pack(fill=X, padx=40, pady=10)

    # Contenedor de botones
    contenido_frame = tb.Frame(app, padding=(PADDING_X, 10))
    contenido_frame.pack()

    # Funciones CRUD
    def crear_producto():
        nombre = simpledialog.askstring("Crear Producto", "Nombre del producto:")
        precio = simpledialog.askfloat("Crear Producto", "Precio del producto:")
        stock = simpledialog.askinteger("Crear Producto", "Cantidad en stock:")

        if nombre and precio is not None and stock is not None:
            try:
                conexion = conectar()
                cursor = conexion.cursor()
                cursor.execute(
                    "INSERT INTO productos (nombre, precio, stock) VALUES (%s, %s, %s)",
                    (nombre, precio, stock)
                )
                conexion.commit()
                conexion.close()
                messagebox.showinfo("Éxito", "Producto creado correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo crear el producto.\n{e}")

    def leer_productos():
        try:
            conexion = conectar()
            cursor = conexion.cursor()
            cursor.execute("SELECT * FROM productos")
            productos = cursor.fetchall()
            conexion.close()

            texto = "\n".join([
                f"ID: {p[0]} | Nombre: {p[1]} | Precio: {p[2]} | Stock: {p[3]}"
                for p in productos
            ])
            messagebox.showinfo("Productos Registrados", texto if texto else "No hay productos registrados.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo leer la tabla productos.\n{e}")

    def actualizar_producto():
        idprod = simpledialog.askinteger("Actualizar Producto", "ID del producto a modificar:")
        nombre = simpledialog.askstring("Actualizar Producto", "Nuevo nombre:")
        precio = simpledialog.askfloat("Actualizar Producto", "Nuevo precio:")
        stock = simpledialog.askinteger("Actualizar Producto", "Nueva cantidad en stock:")

        if idprod and nombre and precio is not None and stock is not None:
            try:
                conexion = conectar()
                cursor = conexion.cursor()
                cursor.execute(
                    "UPDATE productos SET nombre=%s, precio=%s, stock=%s WHERE idprod=%s",
                    (nombre, precio, stock, idprod)
                )
                conexion.commit()
                conexion.close()
                messagebox.showinfo("Éxito", "Producto actualizado correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo actualizar el producto.\n{e}")

    def eliminar_producto():
        idprod = simpledialog.askinteger("Eliminar Producto", "ID del producto a eliminar:")
        if idprod:
            try:
                conexion = conectar()
                cursor = conexion.cursor()
                cursor.execute("DELETE FROM productos WHERE idprod=%s", (idprod,))
                conexion.commit()
                conexion.close()
                messagebox.showinfo("Éxito", "Producto eliminado correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo eliminar el producto.\n{e}")

    # Botones CRUD
    opciones = [
        ("➕  Crear Producto", crear_producto),
        ("📋  Leer Productos", leer_productos),
        ("✏️  Actualizar Producto", actualizar_producto),
        ("🗑️  Eliminar Producto", eliminar_producto),
    ]

    for texto, comando in opciones:
        boton = tb.Button(
            contenido_frame,
            text=texto,
            command=comando,
            bootstyle="primary outline",
            width=30,
            padding=10
        )
        boton.pack(pady=8)

    # Footer
    footer = tb.Label(
        app,
        text="Gestión de Productos - Smoke Shop",
        font=("Segoe UI", 10),
        foreground="#888"
    )
    footer.pack(side="bottom", pady=10)

    # Ejecutar ventana
    app.mainloop()