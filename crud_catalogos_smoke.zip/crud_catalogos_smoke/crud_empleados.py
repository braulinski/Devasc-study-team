import ttkbootstrap as tb  # type: ignore
from ttkbootstrap.constants import *  # type: ignore
from tkinter import messagebox, simpledialog
from conexion import conectar

def abrir_crud_empleados():
    # Crear ventana para CRUD de empleados
    app = tb.Window(themename="flatly")
    app.title("Smoke Shop - Gestión de Empleados")
    app.geometry("900x600")
    app.resizable(False, False)

    # Estilos y fuentes
    FUENTE_TITULO = ("Segoe UI", 34, "bold")
    FUENTE_SUBTITULO = ("Segoe UI", 18)
    FUENTE_BOTON = ("Segoe UI", 13, "bold")
    COLOR_TEXTO = "#222222"
    PADDING_X = 30

    # Header
    header_frame = tb.Frame(app, padding=20)
    header_frame.pack(fill=X)

    titulo = tb.Label(
        header_frame,
        text="Gestión de Empleados",
        font=FUENTE_TITULO,
        foreground=COLOR_TEXTO
    )
    titulo.pack()

    subtitulo = tb.Label(
        header_frame,
        text="Administra los datos de tus empleados",
        font=FUENTE_SUBTITULO,
        foreground="#555"
    )
    subtitulo.pack()

    # Separador visual
    tb.Separator(app, bootstyle="secondary").pack(fill=X, padx=40, pady=10)

    # Contenedor de botones
    contenido_frame = tb.Frame(app, padding=(PADDING_X, 10))
    contenido_frame.pack()

    # Funciones CRUD
    def validar_sexo(sexo):
        return sexo in ['M', 'F', 'O']

    def crear_empleado():
        nombre = simpledialog.askstring("Crear Empleado", "Nombre del empleado:")
        puesto = simpledialog.askstring("Crear Empleado", "Puesto:")
        sexo = simpledialog.askstring("Crear Empleado", "Sexo (M/F/O):")
        telefono = simpledialog.askstring("Crear Empleado", "Teléfono:")

        if nombre and puesto and sexo and telefono:
            sexo = sexo.upper()
            if not validar_sexo(sexo):
                messagebox.showwarning("Atención", "El sexo debe ser 'M', 'F' o 'O'.")
                return

            try:
                conexion = conectar()
                cursor = conexion.cursor()
                cursor.execute(
                    "INSERT INTO empleados (nombre, puesto, sexo, telefono) VALUES (%s, %s, %s, %s)",
                    (nombre, puesto, sexo, telefono)
                )
                conexion.commit()
                conexion.close()
                messagebox.showinfo("Éxito", "Empleado creado correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo crear el empleado.\n{e}")

    def leer_empleados():
        try:
            conexion = conectar()
            cursor = conexion.cursor()
            cursor.execute("SELECT * FROM empleados")
            empleados = cursor.fetchall()
            conexion.close()

            texto = "\n".join([
                f"ID: {e[0]} | Nombre: {e[1]} | Puesto: {e[2]} | Sexo: {e[3]} | Tel: {e[4]}"
                for e in empleados
            ])
            messagebox.showinfo("Empleados Registrados", texto if texto else "No hay empleados registrados.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo leer la tabla empleados.\n{e}")

    def actualizar_empleado():
        idemp = simpledialog.askinteger("Actualizar Empleado", "ID del empleado a modificar:")
        nombre = simpledialog.askstring("Actualizar Empleado", "Nuevo nombre:")
        puesto = simpledialog.askstring("Actualizar Empleado", "Nuevo puesto:")
        sexo = simpledialog.askstring("Actualizar Empleado", "Nuevo sexo (M/F/O):")
        telefono = simpledialog.askstring("Actualizar Empleado", "Nuevo teléfono:")

        if idemp and nombre and puesto and sexo and telefono:
            sexo = sexo.upper()
            if not validar_sexo(sexo):
                messagebox.showwarning("Atención", "El sexo debe ser 'M', 'F' o 'O'.")
                return

            try:
                conexion = conectar()
                cursor = conexion.cursor()
                cursor.execute(
                    "UPDATE empleados SET nombre=%s, puesto=%s, sexo=%s, telefono=%s WHERE idemp=%s",
                    (nombre, puesto, sexo, telefono, idemp)
                )
                conexion.commit()
                conexion.close()
                messagebox.showinfo("Éxito", "Empleado actualizado correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo actualizar el empleado.\n{e}")

    def eliminar_empleado():
        idemp = simpledialog.askinteger("Eliminar Empleado", "ID del empleado a eliminar:")
        if idemp:
            try:
                conexion = conectar()
                cursor = conexion.cursor()
                cursor.execute("DELETE FROM empleados WHERE idemp=%s", (idemp,))
                conexion.commit()
                conexion.close()
                messagebox.showinfo("Éxito", "Empleado eliminado correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo eliminar el empleado.\n{e}")

    # Botones CRUD
    opciones = [
        ("➕  Crear Empleado", crear_empleado),
        ("📋  Leer Empleados", leer_empleados),
        ("✏️  Actualizar Empleado", actualizar_empleado),
        ("🗑️  Eliminar Empleado", eliminar_empleado),
    ]

    for texto, comando in opciones:
        boton = tb.Button(
            contenido_frame,
            text=texto,
            command=comando,
            bootstyle="primary outline",
            width=30,
            padding=10
        )
        boton.pack(pady=8)

    # Footer
    footer = tb.Label(
        app,
        text="Gestión de Empleados - Smoke Shop",
        font=("Segoe UI", 10),
        foreground="#888"
    )
    footer.pack(side="bottom", pady=10)

    # Ejecutar ventana
    app.mainloop()